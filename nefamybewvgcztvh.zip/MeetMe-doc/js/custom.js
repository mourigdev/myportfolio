$(function() {
"use strict";
    
    $('#nav').singlePageNav();
    

});